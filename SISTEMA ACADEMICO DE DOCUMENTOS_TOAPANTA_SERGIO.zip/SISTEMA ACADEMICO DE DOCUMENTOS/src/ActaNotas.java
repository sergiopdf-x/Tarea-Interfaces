public class ActaNotas implements Imprimible{
    private String carrera;

    public ActaNotas(String carrera){
        this.carrera = carrera;
    }

    @Override
    public void imprimir(){
        System.out.println("Imprimiendo notas de la carrera: " + carrera);
    }
}
