public class PagoTarjeta implements Pagable{
    @Override
    public void procesarPago(double monto){
        if (monto > 0){
            double comision = monto * 0.10;
            double total = monto + comision;
            System.out.println("----- PAGO CON TARJETA -----");
            System.out.println("Comision: $" + comision);
            System.out.println("Pago total: $" + total);
        }else{
            System.out.println("Error.Monto no valido");
        }
    }
}
