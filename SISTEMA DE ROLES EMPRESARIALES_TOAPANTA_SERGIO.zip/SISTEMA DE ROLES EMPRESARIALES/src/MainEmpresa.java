import java.util.Scanner;
void main() {
    Scanner sc = new Scanner(System.in);
    Cajero c = new Cajero("Sergio","4520");
    Administrador a = new Administrador("admin","9512");
    Supervisor s = new Supervisor("supervisor1","842");

    System.out.println("----- SISTEMA EMPRESARIAL -----");
    System.out.println("1. Cajero");
    System.out.println("2. Administrador");
    System.out.println("3. Supervisor");
    System.out.print("Ingrese una opcion: ");
    int opcion = sc.nextInt();

    sc.nextLine();

    switch (opcion){
        case 1:
            System.out.print("Usario: ");
            String usuario = sc.nextLine();
            System.out.print("Clave: ");
            String clave = sc.nextLine();

            if (c.iniciarSesion(usuario,clave)){
                c.gestionarDatos();
            }else{
                System.out.println("Datos Incorrectos");
            }
            break;

        case 2:
            System.out.print("Usuario: ");
            String usuarioA = sc.nextLine();
            System.out.print("Clave: ");
            String claveA = sc.nextLine();

            if (a.iniciarSesion(usuarioA,claveA)){
                a.generarReporte();
                a.gestionarDatos();
            }else{
                System.out.println("Datos Incorrectos");
            }
            break;

        case 3:
            System.out.print("Usuario: ");
            String usuarioS = sc.nextLine();
            System.out.print("Clave: ");
            String claveS = sc.nextLine();

            if (s.iniciarSesion(usuarioS,claveS)){
                s.generarReporte();
            }else{
                System.out.println("Datos incorrectos");
            }
            break;

        default:
            System.out.println("Opcion no valida");
    }
}
