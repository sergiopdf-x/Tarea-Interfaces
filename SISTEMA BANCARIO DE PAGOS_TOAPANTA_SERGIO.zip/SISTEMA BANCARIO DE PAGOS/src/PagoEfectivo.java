public class PagoEfectivo implements Pagable{
    @Override
    public void procesarPago(double monto){
        if (monto > 0){
            System.out.println("----- PAGO CON EFECTIVO -----");
            System.out.println("Total en efectivo: $" + monto);
        }else{
            System.out.println("Error.Monto no valido");
        }
    }
}
