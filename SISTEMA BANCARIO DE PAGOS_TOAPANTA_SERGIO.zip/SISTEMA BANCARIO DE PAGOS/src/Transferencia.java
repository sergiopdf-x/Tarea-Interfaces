public class Transferencia implements Pagable{
    @Override
    public void procesarPago(double monto){
        if (monto > 0){
            double comision = monto *0.05;
            double total = monto + comision;
            System.out.println("----- TRANSFERENCIA -----");
            System.out.println("Comision: $" + comision);
            System.out.println("Total a pagar por transferencia: " + total);
        }else{
            System.out.println("Error.Monto no valido.");
        }
    }
}
