public class HorarioAcademico implements Imprimible{
    private String periodo;

    public HorarioAcademico(String periodo){
        this.periodo = periodo;
    }

    @Override
    public void imprimir(){
        System.out.println("Imprimiendo horario del periodo: " + periodo);
    }
}
