void main() {
    Imprimible c = new Certificado("DCA26");
    Imprimible a = new ActaNotas("Desarrollo de software");
    Imprimible h = new HorarioAcademico("2026-A");

    c.imprimir();
    a.imprimir();
    h.imprimir();
}
