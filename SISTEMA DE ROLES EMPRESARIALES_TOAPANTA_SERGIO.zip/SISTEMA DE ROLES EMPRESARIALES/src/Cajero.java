public class Cajero implements Autenticable,Gestionable{
    private String usuario;
    private String clave;

    public Cajero(String usuario,String clave){
        this.usuario = usuario;
        this.clave = clave;
    }

    @Override
    public boolean iniciarSesion(String usuario,String clave){
        return this.usuario.equals(usuario) &&
                this.clave.equals(clave);
    }

    @Override
    public void gestionarDatos(){
        System.out.println("Cajero esta gestionando los datos");
    }
}
