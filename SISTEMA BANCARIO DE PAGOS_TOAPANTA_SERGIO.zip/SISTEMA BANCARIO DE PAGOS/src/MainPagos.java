void main() {
    Pagable efectivo = new PagoEfectivo();
    Pagable tarjeta = new PagoTarjeta();
    Pagable transferencia = new Transferencia();

    efectivo.procesarPago(100);
    tarjeta.procesarPago(60);
    transferencia.procesarPago(700);

    efectivo.procesarPago(-200);
}
