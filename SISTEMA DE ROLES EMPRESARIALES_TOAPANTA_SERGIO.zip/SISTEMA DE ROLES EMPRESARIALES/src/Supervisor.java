public class Supervisor implements Autenticable,Reportable{
    private String usuario;
    private String clave;

    public Supervisor(String usuario,String clave){
        this.usuario = usuario;
        this.clave = clave;
    }

    @Override
    public boolean iniciarSesion(String usuario,String clave){
        return this.usuario.equals(usuario) && this.clave.equals(clave);
    }

    @Override
    public void generarReporte(){
        System.out.println("Generando el reporte por el supervisior");
    }
}
