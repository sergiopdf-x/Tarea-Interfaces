public class Administrador implements Autenticable,Reportable,Gestionable{
    private String usuario;
    private String clave;

    public Administrador(String usuario,String clave){
        this.usuario = usuario;
        this.clave = clave;
    }

    @Override
    public boolean iniciarSesion(String usuario,String clave){
        return this.usuario.equals(usuario) && this.clave.equals(clave);
    }

    @Override
    public void gestionarDatos(){
        System.out.println("El administrador esta gestionando los datos");
    }

    @Override
    public void generarReporte(){
        System.out.println("Generandose reporte administrativo");
    }
}
